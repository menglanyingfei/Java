package org.lxy.controller;

import org.lxy.model.Question;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class TestController {
    @RequestMapping("/hello")
    public String sayHello(ModelMap map) {
        System.out.println("say hello...");
        map.addAttribute("name", " world!");
        // 在return语句中加入 / ,意为找名字为此的文件进行渲染
        return "/hello";
    }


    @RequestMapping("/date")
    public String testDate(ModelMap map) {
        Question question = new Question();
        question.setCreatedDate(new Date());
        map.addAttribute("question", question);

        List<Question> questions = new ArrayList<>();
        questions.add(new Question(new Date(), 5));
        questions.add(question);
        map.addAttribute("questions", questions);

        // 测试为空
        String time = null;
        map.addAttribute("time", time);
        // 测试if else
        Question question1 = new Question(new Date(), 5);
        map.addAttribute("question1", question1);
        return "/datetime";
    }

    @RequestMapping("/hi")
    public String sayHi(ModelMap map) {
        System.out.println("say hi...");
        map.put("name", "haha");
        return "/hi";
    }

    @RequestMapping("/jsp")
    public String jspRequest() {
        System.out.println("jspRequest...");
        return "/temp";
    }
}
