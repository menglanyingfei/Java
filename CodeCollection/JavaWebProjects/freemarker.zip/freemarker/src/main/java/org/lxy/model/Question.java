package org.lxy.model;

import java.util.Date;

/**
 * @Author menglanyingfei
 * @Created on 2018.01.09 13:46
 */
public class Question {
    private Date createdDate;
    private int liked;

    public Question() {}

    public Question(Date createdDate, int liked) {
        this.createdDate = createdDate;
        this.liked = liked;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public int getLiked() {
        return liked;
    }

    public void setLiked(int liked) {
        this.liked = liked;
    }
}
