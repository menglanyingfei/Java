package freemarker;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;
import org.junit.Test;

import java.io.File;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

public class TestFreeMarker {

    @Test
    public void test() throws Exception {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_22);
        cfg.setDirectoryForTemplateLoading(new File("E:\\repository\\Java\\JavaWeb\\freemarker\\src\\test\\resources"));
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

        Template ftl = cfg.getTemplate("user.ftl");

        Map<String, Object> root = new HashMap<>();
        root.put("name", "lxy");
        root.put("password", "123");

        Writer out = new OutputStreamWriter(System.out);
        ftl.process(root, out);
    }

}
